<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="castle" tilewidth="40" tileheight="40" tilecount="40" columns="4">
 <editorsettings>
  <export target="castle.lua" format="lua"/>
 </editorsettings>
 <image source="../../../assets/sprites/tilesets/castle.png" width="160" height="400"/>
</tileset>
