return {
  
plaquecutscene = function(cutscene)

Kristal.Console:log("test")
	 local susie = cutscene:getCharacter("susie")
	 local ralsei = cutscene:getCharacter("ralsei")
        if susie then
		
		cutscene:text("* Golden plaques line the walls to the entrance of the office.")
		cutscene:text("* That grin, shining almost as brightly as the gold itself.")
		cutscene:text("* You became lost in the craftsmanship.")
		
		cutscene:setSpeaker(susie)
            cutscene:text("* Man, this place sure is giving me the creeps...", "neutral_side")
			cutscene:text("* Yeah, [wait:4] it's like...", "neutral_side")
			cutscene:wait(2)
			cutscene:text("* Fancy, and stuff but...", "neutral")
			cutscene:text("* This dumb face and its dumb smile.", "neutral_side")
			cutscene:text("* It's everywhere...", "nervous")
			cutscene:wait(3)
			cutscene:text("* Kris.", "closed_grin")
			cutscene:text("* I swear to god.", "closed_grin")
			cutscene:text("* If we gotta deal with one more self oriented asshole today I'm gonna-", "teeth_b")
			
		cutscene:setSpeaker(ralsei)
            cutscene:text("* Calm now, Susie, he said family friendly, remember?", "smile")
			
		
		cutscene:setSpeaker(susie)
            cutscene:text("* ...", "neutral_side")
			cutscene:text("* ...okay. ", "neutral_side")
			cutscene:text("* You're right. Sorry... about that. ", "neutral_side")
			
			
			
			end
  end,
  
windowcutscene = function(cutscene)

Kristal.Console:log("test")
	 local susie = cutscene:getCharacter("susie")
	 local ralsei = cutscene:getCharacter("ralsei")
        if susie then
		
		cutscene:text("* There is a window here.")
		cutscene:text("* A stunning view lies just outside.")
		
		cutscene:wait(3)
		
		cutscene:setSpeaker(ralsei)
            cutscene:text("* Nice view, right Kris?", "smile")
			cutscene:text("* ..." , "smile")
		cutscene:wait(2)
		
		cutscene:setSpeaker(ralsei)
            cutscene:text("* I[wait:3]-It's alright Kris, you don't have to respond.", "smile_side")
			cutscene:text("* After all, it is quite the view to take in!", "blush_smile")
		cutscene:setSpeaker(susie)
            cutscene:text("* Yeah...", "nervous_side")
			cutscene:text("* It almost makes up for that stupid long elevator ride.", "smirk")
			cutscene:text("* ...", "neutral")
		cutscene:wait(3)
		
		cutscene:setSpeaker(ralsei)
			cutscene:text("* Everything alright, Susie?", "pensive")
			
		cutscene:setSpeaker(susie)
			cutscene:text("* You mean aside from the fact you just kinda... ", "neutral")
			cutscene:text("* Blindly agreed to a weird business deal from those... ", "teeth_smile")
			cutscene:text("* Y'know... ", "nervous_side")
			cutscene:text("* Total strangers earlier? ", "teeth_smile")
		
		cutscene:setSpeaker(ralsei)
			cutscene:text("* ...!", "surprise_confused")
			cutscene:text("* ...", "dismissive")
		
				
		cutscene:setSpeaker(susie)
			cutscene:text("* It's just...", "nervous_side")
			cutscene:text("* I'm starting to think that might've not been the best idea... Heh. ", "teeth_smile" )
			
			cutscene:wait(2)
			
		cutscene:setSpeaker(ralsei)
			cutscene:text("* Well, I thought it might be able to assist us in getting out of here.", "smile")
			cutscene:text("* I figured if we befriend the wealthy man who rules this place...", "small_smile_side_b")
			cutscene:text("* Sealing this dark fountain might not be too hard after all!", "blush_pleased_open")
		
		cutscene:setSpeaker(susie)
			cutscene:text("* Heh! Take advantage of the rich guy.", "smile" )
			cutscene:text("* I like your thinking, Ralsei! ", "teeth_smile" )
			
		cutscene:setSpeaker(ralsei)
			cutscene:text("* ...!", "surprise_confused")
			cutscene:text("* You know that's not what I meant, Susie!", "owo")
			
		cutscene:setSpeaker(susie)
			cutscene:text("* I'm being sarcastic, you know?", "smile")
			
		cutscene:setSpeaker(ralsei)
			cutscene:text("* H[wait:3]-hey!", "owo")
			cutscene:text("* You don't know, maybe I was also being sarcastic!", "wink")
		
		cutscene:setSpeaker(susie)
			cutscene:text("* Haha! [wait:5] You're priceless sometimes, y'know that Ralsei?", "sincere_smile" )
			
		cutscene:setSpeaker(ralsei)
			cutscene:text("* ...!", "blush_surprise")
			
		
		cutscene:setSpeaker(susie)
			cutscene:text("* ...", "shy_b" )
			
			cutscene:wait(5)
			
		cutscene:setSpeaker(susie)
			cutscene:text("* Noelle would be totally geeking out about this view, wouldn't she Kris?", "sincere_smile" )
		
			
			
			
			
			end
  end,
  
  id_b = function(cutscene, var) -- cutscenes can have arguments passed into them
    cutscene:wait(var)
  end
}