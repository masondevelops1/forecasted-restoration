return {

    terminal1 = function(cutscene)
    
    Kristal.Console:log("test")   
        cutscene:text("* I see an audio log here.[wait:5]\n * It reads as follows:") 
        cutscene:text("[color:purple]HELLO, [wait:5] \nTHIS IS WING GASTER.")
        cutscene:text("[color:purple]THE EXPERIMENTS HAVE BEEN, [wait:5] \nINTERESTING.[wait:5].[wait:5].[wait:5]")
        cutscene:text("[color:purple]THINGS HAVE BEEN GETTING A BIT FREAKY HERE IN THE CORE.")
        cutscene:text("[color:purple]THE POOL IS LOOKING REALLY NICE TODAY.[wait:5]\nMAYBE I WILL TAKE A DIP!")
        cutscene:text("[color:purple]GOOD BY!")
        cutscene:text("* I hear a distant splash,[wait:5] followed by harrowing screams.")
        cutscene:text("* That can't be good.")
    
    end,

    }