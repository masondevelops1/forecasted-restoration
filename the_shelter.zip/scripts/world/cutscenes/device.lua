

local textbox = nil

local function keypadInput(cutscene, count, callback)
    count = count or 1
    --setup the keypad
    local keypad =  GonerKeyboard(1, 
    {
            x      = 500,
            y      = 390,
            step_x = 60,
            step_y = 60,
            name_y = 80,
            keyboard = {
                {"1", "2", "3"},
                {"4", "5", "6"},
                {"7", "8", "9"},
                {"^^", "0", "^^"}
            }
    },
    nil, nil
    )
    keypad.layer = WORLD_LAYERS.top
    keypad.choicer.soul.alpha = 2
    keypad:addFX(RecolorFX(0.5,1,0,1))
    Game.world:addChild(keypad)

    keypad.active = true
    keypad.visible = true
    keypad.limit = -1

    keypad.key_callback = function(key, x,y, keypad) --this callback is called whenever a number is pressed, use it to get input
        print("key",x,y, count, #keypad.text, keypad.limit > #keypad.text, key, x,y, keypad)
        local done = false
        if((#keypad.text + 1) >= count ) then
            done = true
            keypad.choicer.done = true
            keypad.choicer:finish(keypad.callback)
            keypad:finish()
        end

        if(callback) then callback(key, x,y, keypad, done) end
    end

    cutscene:wait(
        function()
            return keypad.done
        end
    )

    if(Input.pressed("=")) then
        keypad.active = false
        keypad.visible = false

    end

    keypad.active = false
    keypad.visible = false
    keypad:remove()
    return tonumber(keypad.text)


    
end
return {

	
  
device = function(cutscene, event)

   

	textbox = Textbox(Game.world.camera:getRect())

	--other fonts in assets/fonts
	textbox:setFont("main", 24)
	--if we just use :setTextColor(), we get this weird gloss to the text. you can see for yourself if you comment out the next line and uncomment the line after
	textbox:addFX(RecolorFX(0,0.8,0,1))
	--textbox.text:setTextColor(0,0.8,0,1)
	local signalStatus = ("No Signal...")
	--double \\ on \\User to escape backslash
	
	textbox:setText(string.format([[
		
	%s

	========================================
	DEVICE:\\User
	========================================
	
	[1:] File Explorer
	[2:] Internet
	[3:] Settings
	[0:] Power Off
	
	========================================
	Type in a number to make a selection
	> _
	]], signalStatus))

	
	--these should be self explanitory, you can see more state options in src/engine/objects/text.lua:105
	textbox.text.state.typing_sound = nil
	textbox.text.state.speed = 5
	textbox.text.state.offset_x = 8
	textbox.text.state.offset_y = 8
	
	textbox:setLayer(100)
	

    


	
	--this has to happen last

    

	Game.world:addChild(textbox)

    local num1 = keypadInput(cutscene)
    local _, textbox = cutscene:text("number inputed: "..num1.."\nnow give a 3 digit number. ill stay here unti you're done.",nil,nil,{wait = false})
    textbox:setText(textbox.text.text, function() end)


    cutscene:wait(1)
    local num2 = keypadInput(cutscene, 3,
        function(key, x,y, keypad, done)
            --close that textbox when we're done inputting our number
            if(done) then
                cutscene:tryResume()
                textbox:remove()
            end
        end
    )
    cutscene:text("number inputed: "..num2.."\nsum is ".. (num1+num2))

	--brings up the green number pad on the right side of the screen.
--cutscene is the current custcene
--count the number of digits you want to read (default 1)
--callback is the per-key input function callback(key, x,y, keypad, done)
---- key is the key input, x,y is the cursor postion, keypad is this keypad, and done is whether or not the last digit has been input

end

}